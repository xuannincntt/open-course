const courseLevels = {
    "beginner": "Beginner",
    "intermediate": "Intermediate",
    "advanced": "Advanced" 
}

export default courseLevels;