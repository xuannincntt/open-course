const courseCategories = {
    "technology": "Technology",
    "health": "Health",
    "languages": "Languages",
    "finance": "Finance",
    "other": "Other"
}

export default courseCategories;